using Avalonia.Controls;

namespace FortnitePorting.Controls;

public partial class GroupBox : UserControl
{
    public GroupBox()
    {
        InitializeComponent();
    }
}