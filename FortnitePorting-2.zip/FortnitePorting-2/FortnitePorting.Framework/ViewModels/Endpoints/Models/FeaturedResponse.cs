﻿namespace FortnitePorting.Framework.ViewModels.Endpoints.Models;

public class FeaturedResponse
{
    public string Artist;
    public string ImageURL;
    public string SocialsURL;
}