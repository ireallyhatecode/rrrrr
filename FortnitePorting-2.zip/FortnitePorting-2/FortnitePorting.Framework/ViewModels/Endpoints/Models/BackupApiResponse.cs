namespace FortnitePorting.Framework.ViewModels.Endpoints.Models;

public class BackupApiResponse<T>
{
    public bool Active;
    public T Data;
}