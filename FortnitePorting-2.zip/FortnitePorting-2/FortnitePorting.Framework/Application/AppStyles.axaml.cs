using Avalonia.Styling;

namespace FortnitePorting.Framework.Application;

public class AppStyles : Styles
{
    
}